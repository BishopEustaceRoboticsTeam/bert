/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

/** 
 * Java code written post-season for SERT's, team 2521's, robot "cyclops" 
 * 
 * @author Aubrey Anderson
 */

package RobotCode;

import robotemulator.*;



//import edu.wpi.first.wpilibj.IterativeRobot;
//import edu.wpi.first.wpilibj.Joystick;
//import edu.wpi.first.wpilibj.Solenoid;
//import java.util.Timer;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class RobotMain /*extends IterativeRobot*/ {
    Joystick joystick1;
    Joystick joystick2;
    Joystick joystick3;
    Solenoid stopper;
    MyDrive drive;
    Lift lift;
    Pivot pivot;
    //MyCamera camera;
    Shooter shooter;
    Bridge bridge;
    double autoDist;

    public void robotInit() {
        stopper = new Solenoid(1);
        joystick1 = new Joystick(1);
        joystick2 = new Joystick(2);
        joystick3 = new Joystick(3);
        drive = new MyDrive(1, 2);
        lift = new Lift(3);
        pivot = new Pivot(4);
        bridge = new Bridge(5);
        //camera = new MyCamera();
        shooter = new Shooter(6);
        
        stopper.set(false);
    }

    /**
     * This function is called periodically during autonomous
     */
    public void autonomousInit() {
        stopper.set(false);
        drive.drive(0.0 , 0.0);
        
        for (int i = 0; i <= 10; i++) {
            //pivot.target(camera.getTarget());
            //shooter.auto(camera.getDistance());
        }
        
        //autoDist = camera.getDistance(); 
    }
    
    public void autonomousContinuous() {
        shooter.auto(autoDist);
        stopper.set(true);
        lift.set(.4);
        drive.drive(0,0);
    }

    /**
     * This function is called periodically during operator control
     */
    public void teleopContinuous() {
        if (joystick1.getRawButton(1) || joystick2.getRawButton(1)) {
            drive.balance();
        } else {
            drive.superDrive(joystick1, joystick2);
        }
        
        if (joystick1.getRawButton(11) || joystick2.getRawButton(11)) {
            if (drive.getArcade()) {
                drive.setArcade(false);
            } else {
                drive.setArcade(true);
            }
        }
        
                
        if (joystick3.getRawButton(4)) {
            //pivot.target(camera.getTarget());
        } else if (joystick3.getRawButton(2)) {
            pivot.limit(joystick3.getRawAxis(2));
        } else if (joystick3.getRawButton(8) || joystick3.getRawButton(9)) {
            pivot.center();
        } else if (pivot.getSpeed() != 0) {
        } else {
            pivot.set(0);
        }
        
        if (joystick3.getRawButton(1)) {
                //shooter.auto(camera.getDistance());
        } else if (joystick3.getRawButton(3)) {
            shooter.manual(joystick3.getRawAxis(2));
        } else if (shooter.getSpeed() != 0) {
        } else {    
                shooter.set(0);
        }
            
        lift.lSet(joystick3.getRawAxis(3));
        
        if (joystick3.getRawButton(5)) {
            stopper.set(true);
        } else if (stopper.get()) {
            stopper.set(false);
        }
        
        if (joystick3.getRawButton(9)) {
            bridge.push(joystick3.getRawAxis(2), true);
        } else if (bridge.get() != 0) {
            bridge.push(joystick3.getRawAxis(2), false);
        }
        
        //System.out.println(camera.distanceAvg);
        
    }
    
    public void teleopInit() {
        drive.drive(0, 0);
        shooter.set(0);
        pivot.set(0);
        lift.set(0);
        bridge.set(0);
        stopper.set(false);
    }
    
    public void teleopPeriodic() {
        System.out.println("periodic");
    }
    
    public void autonomousPeriodic() {}
    
    public void disabledInit() {
        drive.drive(0, 0);
        shooter.set(0);
        pivot.set(0);
        lift.set(0);  
        bridge.set(0);
        stopper.set(false);
    }
    
    public void disabledContinuous() {
        drive.drive(0, 0);
        shooter.set(0);
        pivot.set(0);
        lift.set(0);  
        bridge.set(0);
        
    }
}   
            
       

