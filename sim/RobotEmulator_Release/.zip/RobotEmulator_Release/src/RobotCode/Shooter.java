/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RobotCode;

//import edu.wpi.first.wpilibj.Jaguar;

import robotemulator.Jaguar;


/**
 * Extends Jaguar
 * 
 * @author Aubrey
 */
public class Shooter extends Jaguar {
   
    /**
     * Constructor for Shooter
     * 
     * @param channel channel the shooter jag is in
     */
    public Shooter(final int channel) {
        super(channel);
    }
    
    /**
     * Sets the Shooter to the given value
     * 
     * @param valueIn value to set the shooter to
     */
    public void manual(double valueIn) {
        set(valueIn);
    }
    
    /**
     * Sets the shooter to the correct speed for the given distance
     * 
     * @param distanceIn distance to target
     */
    public void auto(double distanceIn) {
        set((((distanceIn * distanceIn) * .0009)+.4)*-1);
    }
}
