/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RobotCode;

import robotemulator.*;

/**
 *
 * @author Aubrey
 */
public class Bridge extends Victor{
    AnalogChannel bridgePot;
    static boolean isUp = true;
    
    /**
     * constructor for the Bridge Pusher
     * @param channel channel the jag is in
     */
    public Bridge(final int channel) {
        super(channel);
        bridgePot = new AnalogChannel(4);
        
    }
    /**
     * Pushes the bridge and return when false
     * 
     * @param valueIn value to set the pusher to
     * @param tf if false return back to up position
     */
    public void push(double valueIn, boolean tf) {
        if (!isUp) {
            if (bridgePot.getVoltage() < 1.8) {
                isUp = true;
            }
           
            if (tf) {
                set((41 / 12) * valueIn);
            } else {
                set(1);
            }                        
        } else {
            if (bridgePot.getVoltage() > 2) {
                isUp = false;
            }
            if (tf) {
                set(-1);
            } else {
                set(0);
            }
        }
    }
    
}
