///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package RobotCode;
//
//import edu.wpi.first.wpilibj.camera.AxisCamera;
//import edu.wpi.first.wpilibj.camera.AxisCameraException;
//import edu.wpi.first.wpilibj.image.*;
//
///**
// *
// * @author Aubrey
// */
//public class MyCamera {
//    AxisCamera camera;
//    double distanceAvg; 
//    double target;
//    double targetHeight;
//    double[] dist = new double[21];
//    CriteriaCollection cc;      // create the criteria for the particle filter
//    private double[] targetData = new double[2];
//    private int i = 0;
//    private int b = 0;
//    private boolean over21 = false;
//    
//    /**
//     * Constructor for Camera
//     */
//    public void MyCamera() {
//        camera = AxisCamera.getInstance("10.25.21.11");
//        //camera = new AxisCamera("10.25.21.11");
//        cc = new CriteriaCollection();
//        cc.addCriteria(NIVision.MeasurementType.IMAQ_MT_BOUNDING_RECT_WIDTH, 30, 400, false);
//        cc.addCriteria(NIVision.MeasurementType.IMAQ_MT_BOUNDING_RECT_HEIGHT, 40, 400, false);
//        if (camera == null) System.out.println(camera);
//        
//    }
//    
//    /**
//     * Stores the current normalized x position of the target
//     * and the distance to the target in an array
//     */
//    public void getTargetData() {
//            try {
//                b++;
//                /**
//                 * Do the image capture with the camera and apply the algorithm described above. This
//                 * sample will either get images from the camera or from an image file stored in the top
//                 * level directory in the flash memory on the cRIO. The file name in this case is "10ft2.jpg"
//                 * 
//                 */ 
//                
//                camera.writeResolution(AxisCamera.ResolutionT.k320x240);
//                ColorImage image = camera.getImage();     // comment if using stored images
////                ColorImage image;                           // next 2 lines read image from flash on cRIO
////                image =  new RGBImage("/10ft2.jpg");
//               
//                BinaryImage thresholdImage = image.thresholdRGB(100, 255, 0, 45, 0, 47);   // keep only green objects
//                BinaryImage bigObjectsImage = thresholdImage.removeSmallObjects(false, 2);  // remove small artifacts
//                BinaryImage convexHullImage = bigObjectsImage.convexHull(false);          // fill in occluded rectangles
//                BinaryImage filteredImage = convexHullImage.particleFilter(cc);           // find filled in rectangles
//                
//                ParticleAnalysisReport[] reports = filteredImage.getOrderedParticleAnalysisReports();  // get list of results
//                for (int a = 0; a < reports.length; a++) {                                // print results
//                    ParticleAnalysisReport r = reports[a];
//                    System.out.println("Particle: " + a + ":  Center of mass x: " + r.center_mass_x);
//                    if (r.center_mass_y > 100 && r.center_mass_y < 240) {
//                        targetHeight = r.boundingRectHeight;
//                        target = r.center_mass_x_normalized;
//                        System.out.println(target);
//                        System.out.println(targetHeight);
//                    }
//                }
//                
//                double targetProp = ((1.5/targetHeight)*240)/2;
//                double targetLengths = Math.tan(Math.toRadians(24));
//                double distance = targetProp / targetLengths;
//                double distTotal = 0;
//                distanceAvg = distance;
////                dist[i] = distance;
////                i++;
////                
////                if (b == 21) {
////                    over21 = true;
////                }
////                
////                if (i < 21 && !over21) {
////                    for (int j = 0; j < i; j++) {
////                        distTotal += dist[j];
////                    }
////                    distanceAvg = distTotal / i;
////                } else {
////                    for (int j = 0; j < i; j++) {
////                        distTotal += dist[j];
////                    }
////                    distanceAvg = distTotal / 21;
////                    i = 0;
////                }
//                
//       
//                
//                /**
//                 * all images in Java must be freed after they are used since they are allocated out
//                 * of C data structures. Not calling free() will cause the memory to accumulate over
//                 * each pass of this loop.
//                 */
//                filteredImage.free();
//                convexHullImage.free();
//                bigObjectsImage.free();
//                thresholdImage.free();
//                image.free();
//                
//            } catch (AxisCameraException ex) {  ex.printStackTrace();
//            } catch (NullPointerException ex) { ex.printStackTrace();
//            } catch (NIVisionException ex) { ex.printStackTrace();
//            }
//        
//        
//        targetData[0] = distanceAvg;
//        targetData[1] = target;        
//    }
//            /**
//             * Calculates the most recent Target Data
//             * 
//             * @return Distance to target 
//             */
//            public double getDistance() {
//                getTargetData();
//                return targetData[0];
//            }
//            
//            /**
//             * Calculates the most recent Target Data
//             * 
//             * @return normalized x position of target
//             */
//            public double getTarget() {
//                getTargetData();
//                return targetData[1];
//            }
//    }
//
