/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RobotCode;

//import edu.wpi.first.wpilibj.AnalogChannel;

import robotemulator.*;

//import edu.wpi.first.wpilibj.Jaguar;

/**
 *
 * @author Aubrey
 */
public class Pivot extends Jaguar {
    AnalogChannel pivotPot;
    
    /**
     * Constructor for Pivot
     * 
     * @param channel 
     */
    public Pivot(final int channel) {
        super(channel);
        pivotPot = new AnalogChannel(3);
    }
    
    /** 
     * Given a normalized x value of particle,
     *  centers a rotational motor on the particle
     * 
     * @param xCoord normalized x value of a particle
     */
    public void target(double xCoord) {
        double SET_POINT = 1;
        double MARGIN_OF_ERROR = .01;
        double MAX_LIMIT = 2;
        double MIN_LIMIT = 0;
        double position = xCoord + 1; 
        double dvoltage;
        double spposub;
        double romadd;
        boolean dtwo;
        boolean dfour;
        boolean deight;
                
        dvoltage = Math.abs(SET_POINT - position);
        if (dvoltage <= MARGIN_OF_ERROR) {
            set(0);
        }
        else {
            romadd = (Math.abs(MAX_LIMIT + MIN_LIMIT));
            spposub = Math.abs(Math.abs(SET_POINT) - Math.abs(position));
            dtwo = spposub <= (romadd/2);
            dfour = spposub < (romadd/4);
            deight = spposub <= (romadd/8);
            if ((SET_POINT - position) < 0) {
               if (dtwo && !dfour && !deight) {
                   set(-.4);
               }
               else if (dtwo && dfour && !deight)  {
                   set(-.3);
               }
               else if (dtwo && dfour && deight) {
                   set(-.2);
               }
               else {
                   set(-.5);
               }   
            }
            else {
                if (dtwo && !dfour && !deight) {
                   set(.4);
               }
               else if (dtwo && dfour && !deight)  {
                   set(.3);
               }
               else if (dtwo && dfour && deight) {
                   set (2);
               }
               else {
                   set(.5);
               }  
            }
        }
    }
    
    /**
     * Limits the Pivot inside the correct range
     * 
     * @param valueIn value to set the pivot motor to
     */
    public void limit(double valueIn) {
        valueIn = -valueIn;
        if (0 < valueIn) {
            if (1.54 > pivotPot.getVoltage()) {
                set(0);
            } else {
                set(valueIn);
            }
        } else {
            if (2.8 < pivotPot.getVoltage()) {
                set(0);
            } else {
                set(valueIn);
            }
        }
    }
    
    /**
     * centers the Pivot
     */
    public void center() {
        double SET_POINT = 2.16;
        double MARGIN_OF_ERROR = .03;
        double MAX_LIMIT = 2.2;
        double MIN_LIMIT = 1.5;
        double position = pivotPot.getVoltage(); 
        double dvoltage;
        double spposub;
        double romadd;
        boolean dtwo;
        boolean dfour;
        boolean deight;
                
        dvoltage = Math.abs(SET_POINT - position);
        if (dvoltage <= MARGIN_OF_ERROR) {
            set(0);
        }
        else {
            romadd = (Math.abs(MAX_LIMIT + MIN_LIMIT));
            spposub = Math.abs(Math.abs(SET_POINT) - Math.abs(position));
            dtwo = spposub <= (romadd/2);
            dfour = spposub < (romadd/4);
            deight = spposub <= (romadd/8);
            if ((SET_POINT - position) < 0) {
               if (dtwo && !dfour && !deight) {
                   set(-.4);
               }
               else if (dtwo && dfour && !deight)  {
                   set(-.3);
               }
               else if (dtwo && dfour && deight) {
                   set(-.2);
               }
               else {
                   set(-.5);
               }   
            }
            else {
                if (dtwo && !dfour && !deight) {
                   set(.4);
               }
               else if (dtwo && dfour && !deight)  {
                   set(.3);
               }
               else if (dtwo && dfour && deight) {
                   set(.2);
               }
               else {
                   set(.5);
               }  
            }
        }
    }
}