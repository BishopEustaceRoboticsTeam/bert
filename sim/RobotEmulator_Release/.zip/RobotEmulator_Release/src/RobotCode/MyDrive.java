/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RobotCode;

import robotemulator.*;


/**
 * Extends RobotDrive
 * 
 * @author Aubrey
 */
public class MyDrive extends RobotDrive {
    Joystick joystick1;
    Joystick joystick2;
    Gyro balanceGyro;
    boolean isArcade = true;
    
    /**
     * Constructor for MyDrive
     * 
     * @param channel1 channel for the left drive
     * @param channel2 channel for the right drive
     */
    public MyDrive(final int channel1, final int channel2) {
        super(channel1, channel2);
        balanceGyro = new Gyro(2);
        balanceGyro.reset();
    }
    
    /**
     * Drives in either Arcade or Tank drive depending
     * on what isArcade is set to (default true)
     * 
     * @param joystick1 joystick used for arcade mode or tank drive
     * @param joystick2 joystick used only for tank drive
     */
    public void superDrive(Joystick joystick1, Joystick joystick2) {
        if (isArcade) {
            arcadeDrive(joystick1);
        } else {
            tankDrive(joystick1, joystick2);
        }
    }
    
    /**
     * Sets whether or not to run in Arcade or Tank drive
     * 
     * @param set if True: Arcade Drive
     * @param set if False: Tank Drive
     */
    public void setArcade (boolean set) {
        if (set && !isArcade) {
            isArcade = true;
        }
        else if (!set && isArcade){
            isArcade = false;
        }
    }
    
    /**
     * Gets Arcade Mode
     * 
     * @return True: Arcade Drive
     * @return False: Tank Drive
     */
    public boolean getArcade() {
        return isArcade;
    }
    
    /**
     * Uses the Drive to balance the bridge given the gyro reading
     */
    public void balance() {
        double MAX_LIMIT = 360;
        double MIN_LIMIT = 0;
        double MARGIN_OF_ERROR = 2;
        double SETPOINT = 0;
        double SCALER = 1;
        double angle = balanceGyro.getAngle();
        boolean canCrossZero = true;
        double remainder;
        double spposub;
        double romadd;
        double subadd1;
        double subadd2;
        double remsetsub;
        double mout1;
        double romd4;
        boolean[] boola = new boolean[3];
        boolean[] boolb = new boolean[3];
        boolean[] boolc = new boolean[3];
        boolean[] boold = new boolean[]{false, false, false};
        boolean[] boole = new boolean[4];
        
        remainder = angle % (MAX_LIMIT - MIN_LIMIT);
        romadd = Math.abs(MAX_LIMIT) + Math.abs(MIN_LIMIT);
        spposub = Math.abs(Math.abs(SETPOINT) - Math.abs(remainder));
        subadd1 = (MAX_LIMIT -SETPOINT) + (angle - MIN_LIMIT);
        subadd2 = (MIN_LIMIT - angle) + (SETPOINT - MAX_LIMIT);
        remsetsub  = Math.abs(Math.abs(SETPOINT) - Math.abs(remainder));
        romd4 = (MAX_LIMIT + MIN_LIMIT) / 4;
        
        boola[0] = (spposub <= (romadd / 3));        
        boola[1] = (subadd1 <= (romadd / 3));
        boola[2] = (subadd2 <= (romadd / 3));
        boolb[0] = (spposub <= (romadd / 4));        
        boolb[1] = (subadd1 <= (romadd / 4));
        boolb[2] = (subadd2 <= (romadd / 4));
        boolc[0] = (spposub <= (romadd / 8));        
        boolc[1] = (subadd1 <= (romadd / 8));
        boolc[2] = (subadd2 <= (romadd / 8));
       
        for(int f = 0; f <= 2; f++) {
            if (boola[f]) {
                boold[0] = true;
            }
            
            if (boolb[f]) {
                boold[1] = true;
            }
            
            if (boolc[f]) {
                boold[2] = true;
            }
        }
        
        if (boold[0]) {
            mout1 = .1;
        } else if (boold[1]) {
            mout1 = .2;
        } else if (boold[2]) {
            mout1 = .3;
         } else {
            mout1 = .5;
        }
        
        boole[0] = remainder <= romd4;
        boole[1] = remainder >= (romd4 * 3);
        boole[2] = SETPOINT <= romd4;
        boole[3] = SETPOINT >= (romd4 * 3);
        int b = 0;
        
        if (MARGIN_OF_ERROR > spposub) {
            for (int j = 0; j <= 3; j++) {
                b |= (boole[j] ? 1 : 0);
                b = b << 1;
            }
            
            if (b == 15 || b == 14 || b == 13 || b == 12 || b == 11 || b == 7 || b == 3) {
                drive(0,0);
            } else if (b == 10 || b == 5) {
                if (SETPOINT > remainder) {
                    drive(mout1, 0);
                } else {
                    drive(-mout1, 0);
                }
            } else if (b == 9) {
                drive(-mout1, 0);
            } else if (b == 8 || b == 1) {
                if ((SETPOINT - remainder) > (romadd / 2)) {
                    drive(-mout1, 0);
                } else {
                    drive(mout1, 0);
                }
            } else if (b == 6) {
                drive(mout1, 0);
            } else if (b == 4 || b == 2) {
                if (Math.abs(SETPOINT - remainder) < (romadd / 2)) {
                    drive(-mout1, 0);
                } else {
                    drive(mout1, 0);
                }
            } else {
                if ((SETPOINT - remainder) < 0) {
                    drive(-mout1, 0);
                } else {
                    drive(mout1, 0);
                }
            }
        } else { 
            drive(0 ,0);
        }
    }
}
