/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RobotCode;


import robotemulator.*;

/**
 *
 * @author Aubrey
 */
public class Lift extends Jaguar {
    
    /**
     * Constructor for Lift
     * 
     * @param channel channel of Jag
     */
    public Lift(final int channel) {
        super(channel);
    }
    
    /**
     * sets the zero position to be the top of the throttle
     * 
     * @param valueIn throttle value
     */
    public void lSet(double valueIn) {
        set((valueIn + 1)/-2);
    }
}
    
